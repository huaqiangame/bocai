<div class="update_header am-modal-actions"  id="my-actions">
    <div class="update_header_title am-cf">
        <h3 class="am-fl">修改头像</h3>
        <i class="iconfont icon-cross-ivt am-fr" data-am-modal-close></i>
    </div>
    <div class="update_header_main">
        <span class="preview am-block">预览</span>
        <div class="img"><img class="update_header_img" src="__IMG__/C6021F3486D2B2DB.jpg" alt=""></div>
        <em class="update_header_name am-block">比尔盖茨</em>
        <div class="update_header_list">
            <div class="prev"><i class="am-datepicker-prev-icon"></i></div>
            <div class="update_header_imgs_box">
                <div class="update_header_imgs am-cf" id="update_header_imgs">
                    <img class="update_header_watch" src="__IMG__/0A472675E5E5AF50.jpg" alt="奥巴马">
                    <img class="update_header_watch" src="__IMG__/1B6A214FF62BD91F.jpg" alt="小女孩">
                    <img class="update_header_watch" src="__IMG__/1EF6FC3ACCBCD762.jpg" alt="泷泽萝拉">
                    <img class="update_header_watch" src="__IMG__/4A2E3EA214381904.jpg" alt="科比">
                    <img class="update_header_watch" src="__IMG__/4D73D09EC5D7BFE3.jpg" alt="金正恩">
                    <img class="update_header_watch" src="__IMG__/5C5A53823438F2CD.jpg" alt="杰森斯坦森">
                    <img class="update_header_watch" src="__IMG__/6EC9EDCC7B3BD70D.jpg" alt="梅西">
                    <img class="update_header_watch" src="__IMG__/6F1A99A3D02A6DEC.jpg" alt="范冰冰">
                    <img class="update_header_watch" src="__IMG__/9A9C9E1A719CE536.jpg" alt="本拉登">
                    <img class="update_header_watch" src="__IMG__/831CA133362DE10D.jpg" alt="萨达姆">
                    <img class="update_header_watch" src="__IMG__/3578E1EB410B49C7.jpg" alt="宋慧乔">
                    <img class="update_header_watch" src="__IMG__/9816F54B27A9BF48.jpg" alt="李敏镐">
                    <img class="update_header_watch" src="__IMG__/367498B6A748D910.jpg" alt="宋仲基">
                    <img class="update_header_watch" src="__IMG__/A9734CC321C8B363.jpg" alt="比尔盖茨">
                    <img class="update_header_watch" src="__IMG__/C7BB5088540C8040.jpg" alt="罗纳尔多">
                    <img class="update_header_watch" src="__IMG__/C362F2B1E0EA389A.jpg" alt="宋承宪">
                    <img class="update_header_watch" src="__IMG__/C6021F3486D2B2DB.jpg" alt="小男孩">
                    <img class="update_header_watch" src="__IMG__/C707188A6E10AED4.jpg" alt="朴信惠">
                    <img class="update_header_watch" src="__IMG__/CA64E00C3F9FD5F3.jpg" alt="希拉里">
                    <img class="update_header_watch" src="__IMG__/D38F599DF12CD206.jpg" alt="全智贤">
                    <img class="update_header_watch" src="__IMG__/E6CA6EB9F492879E.jpg" alt="林允儿">
                    <img class="update_header_watch" src="__IMG__/EED50A5799E76E58.jpg" alt="普京">
                    <img class="update_header_watch" src="__IMG__/EF01C8BED7B70053.jpg" alt="波多野结衣">
                    <img class="update_header_watch" src="__IMG__/F0E57CF931E45118.jpg" alt="贝克汉姆">
                    <img class="update_header_watch" src="__IMG__/F95FE943163DAF92.jpg" alt="苍井空">
                </div>
            </div>
            <div class="next"><i class="am-datepicker-next-icon"></i></div>
        </div>
    </div>
    <div class="update_header_bottom">
        <button class="am-btn am-btn-default am-radius btn_red save saveface" data-am-modal-close>确定</button>
        <button class="am-btn am-btn-default am-radius close" style="background-color: #828282;" data-am-modal-close>取消</button>
    </div>
</div>
