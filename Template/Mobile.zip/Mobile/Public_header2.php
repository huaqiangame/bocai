          <header class="bar bar-nav theme-red">

				  <a class="button button-link button-nav pull-left bar-nav-top-left" href="javascript:history.go(-1);">
					  <span class="icon icon-left"></span>
				  </a>

				   <h1 class="title" style="position:static;text-align:center;">{$webheadertitle}</h1>

          </header>
          <nav class="bar bar-tab" style="background-color: #000;">
              <a class="tab-item external active" href="__ROOT__/" style="color: #fff;">
                  <span class="iconfont icon-shouyeshouye1" style="font-size: 25px;line-height: 17px;padding-top: 7px;display: block;"></span>
                  <span class="tab-label" style="font-size:12px;">购彩大厅</span>
              </a>
              <a class="tab-item external" href="{:U('Member/betRecord')}" style="color: #fff;">
                  <span class="iconfont icon-touzhujilu" style="font-size: 25px;line-height: 17px;padding-top: 7px;display: block;"></span>
                  <span class="tab-label" style="font-size:12px;">投注记录</span>
              </a>
              <a class="tab-item external" href="{:GetVar('kefuthree')}" style="color: #fff;">
                  <span class="iconfont icon-kefu" style="font-size: 25px;line-height: 17px;padding-top: 7px;display: block;"></span>
                  <span class="tab-label" style="font-size:12px;">在线客服</span>
              </a>
              <a class="tab-item external" href="{:U('Member/index')}" style="color: #fff;">
                  <span class="iconfont icon-wode" style="font-size: 25px;line-height: 17px;padding-top: 7px;display: block;"></span>
                   <span class="tab-label" style="font-size:12px;">我的账户</span>
              </a>
          </nav>
