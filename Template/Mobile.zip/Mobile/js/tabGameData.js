  //六合彩开始
  //特码直选
  var lhc_tmzx_arr = [
    {
      'tmzx': '直选A', 
      'tmzx2': '直选B',
      'tmlm': '两面'
    }
  ];
  var lhc_tmzx_title = ['特码'];
  var lhc_tmzx_num = ['号码'];
  //特码两面
  var lhc_tmlm_content = ['大','小','单','双','大单','大双',
                      '小单','小双','合大','合小','合单','合双',
                      '尾大','尾小','家禽','野兽','红波','绿波','蓝波'];
  //特码半波
  var lhc_tmbb_arr = [
    {
      'tmbb': '特码半波'
    }
  ];
  var lhc_tmbb_title = ['半波'];
  var lhc_tmbb_content = ['红大|29 30 34 35 40 45 46','红小|01 02 07 08 12 13 18 19 23 24',
                          '红单|01 07 13 19 23 29 35 45','红双|02 08 12 18 24 30 34 40 46',
                          '红合单|01 07 12 18 23 29 30 34 45','红合双|02 08 13 19 24 35 40 46',
                          '绿大|27 28 32 33 38 39 43 44 49','绿小|05 06 11 16 17 21 22',
                          '绿单|05 11 17 21 27 33 39 43 49','绿双|06 16 22 28 32 38 44',
                          '绿合单|05 16 21 27 32 38 43 49','绿合双|06 11 17 22 28 33 39 44',
                          '蓝大|25 26 31 36 37 41 42 47 48','蓝小|03 04 09 10 14 15 20',
                          '蓝单|03 09 15 25 31 37 41 47','蓝双|04 10 14 20 26 36 42 48',
                          '蓝合单|03 09 10 14 25 36 41 47','蓝合双|04 15 20 26 31 37 42 48'];
  //生肖
  var lhc_sxtx_arr = [
    {
      'sxtx': '特肖',
      'sx1x': '一肖',
      'sx2xl': '二肖连',
      'sx3xl': '三肖连',
      'sx4xl': '四肖连',
    }
  ];
  var lhc_sxtx_title = ['生肖'];
  var lhc_sxtx_content = ['鼠|11 23 35 47','牛|10 22 34 46',
                          '虎|09 21 33 45','兔|08 20 32 44',
                          '龙|07 19 31 43','蛇|06 18 30 42',
                          '马|05 17 29 41','羊|04 16 28 40',
                          '猴|03 15 27 39','鸡|02 14 26 38',
                          '狗|01 13 25 37 49','猪|12 24 36 48'];
  //尾数
  var lhc_wstw_arr = [
    {
      'wstw': '特码头尾',
      'ws2wl': '二尾连',
      'ws3wl': '三尾连',
      'ws4wl': '四尾连',
    }
  ];
  var lhc_wstw_title = ['尾数'];
  var lhc_wstw_content = ['0头','1头','2头','3头','4头',
                          '0尾','1尾','2尾','3尾','4尾','5尾','6尾','7尾','8尾','9尾',];
  var lhc_wstw_content1 = ['0尾','1尾','2尾','3尾','4尾','5尾','6尾','7尾','8尾','9尾',];
  //不中
  var lhc_bz5bz_arr = [
    {
      'bz5bz': '五不中',
      'bz6bz': '六不中',
      'bz7bz': '七不中',
      'bz8bz': '八不中',
      'bz9bz': '九不中',
      'bz10bz': '十不中',
    }
  ];
  var lhc_bz5bz_title = ['不中'];
  //正码
  var lhc_zmrx_arr = [
    {
      'zmrx': '任选',
      'zm1t': '正 1 特',
      'zm1lm': '正 1 两面',
      'zm2t': '正 2 特',
      'zm2lm': '正 2 两面',
      'zm3t': '正 3 特',
      'zm3lm': '正 3 两面',
      'zm4t': '正 4 特',
      'zm4lm': '正 4 两面',
      'zm5t': '正 5 特',
      'zm5lm': '正 5 两面',
      'zm6t': '正 6 特',
      'zm6lm': '正 6 两面',
    }
  ];
  var lhc_zmrx_title = ['正码'];
  //连码
  var lhc_lm3qz_arr = [
    {
      'lm3qz': '三全中',
      'lm3z2': '三中二',
      'lm2qz': '二全中',
      'lm2zt': '二中特',
      'lmtc': '特串',
    }
  ];
  var lhc_lm3qz_title = ['连码'];
  //六合彩结束  
//时时彩开始
  // 五星字段
  var ssc_5x_arr = [
    {
      'wxzhixfs': '复式',
      'wxzhixds': '单式'
    },
    {
      'wxzxyel': '组选120',
      'wxzxls': '组选60',
      'wxzxsl': '组选30',
      'wxzxel': '组选20',
      'wxzxyl': '组选10',
      'wxzxw': '组选5'
    },{
      'bdw5x1m': '一码不定位',
      'bdw5x2m': '二码不定位',
      'bdw5x3m': '三码不定位'
    },{
      'qwyffs': '一帆风顺',
      'qwhscs': '好事成双',
      'qwsxbx': '三星报喜',
      'qwsjfc': '四季发财'
    }
  ];
  var ssc_5x_title = ['直选','组选','不定位','趣味'];
  //五星复式
  var wx_fs = ['万位','千位','百位','十位','个位'];
  var wx_zx_120 = ['组选120'];
  var wx_zx_60 = ['二重号位','单号位'];
  var wx_zx_20 = ['三重号位','单号位'];
  var wx_zx_10 = ['三重号位','二重号位'];
  var wx_zx_5 = ['四重号位','单号位'];
  var wx_bdw = ['不定位'];
  // 四星字段
  var ssc_4x_arr = [
    {
      'sixzhixfsh': '复式',
      'sixzhixdsh': '单式'
    },
    {
      'hsizxes': '组选24',
      'hsizxye': '组选12',
      'hsizxl': '组选6',
      'hsizxs': '组选4'
    },{
      'bdw4x1m': '一码不定位',
      'bdw4x2m': '二码不定位'
    }
  ];
  var ssc_4x_title = ['直选','组选','不定位'];
  //四星
  var sx_fs = ['千位','百位','十位','个位'];
  var sx_zx24 = ['组选24'];
  var sx_zx12 = ['二重号位','单号位'];
  var sx_zx6 = ['二重号位'];
  var sx_zx4 = ['三重号位','单号位'];
  var sx_bdw = ['不定位'];
   // 前三/中三/后三字段
  var ssc_q3_arr = [
    {
      'sxzhixfsq': '复式',
      'sxzhixdsq': '单式',
      'zhixhzqs': '直选和值',
      'kuaduqs': '跨度'
    },
    {
      'zuxhzqs': '组选和值',
      'sxzuxzsq': '组3',
      'sxzuxzlq': '组6',
      'sxhhzxq': '混合组选',
      'zuxcsbd': '组选包胆',
      'qszsds': '组三单式',
      'qszlds': '组六单式'
    },{
      'bdwqs': '一码不定位',
      'bdwqs2m': '二码不定位'
    }
  ];
  var ssc_q3_title = ['直选','组选','不定位'];
   //前三
   var q3_sxzhixfsq = ['万位','千位','百位'];
   var z3_sxzhixfsq = ['千位','百位','十位'];
   var h3_sxzhixfsq = ['百位','个位','十位'];
   var q3_zhixhzqs = ['和值'];
   var q3_kuaduqs = ['跨度'];
   var q3_sxzuxzsq = ['组3'];
   var q3_sxzuxzlq = ['组6'];
   var zuxcsbd = ['包胆'];
   var q3_bdw = ['不定位'];
   //中三
  var ssc_z3_arr = [
      {
        'sxzhixfsz': '复式',
        'sxzhixdsz': '单式',
        'zhixhzzs': '直选和值',
        'kuaduzs': '跨度'
      },
      {
        'zuxhzzs': '组选和值',
        'sxzuxzsz': '组3',
        'sxzuxzlz': '组6',
        'sxhhzxz': '混合组选',
        'zuxzsbd': '组选包胆',
        'zszsds': '组三单式',
        'zszlds': '组六单式'
      },{
        'bdwzs': '一码不定位',
        'bdwzs2m': '二码不定位'
      }
    ];
  //后三
  var ssc_h3_arr = [
      {
        'sxzhixfsh': '复式',
        'sxzhixdsh': '单式',
        'zhixhzhs': '直选和值',
        'kuaduhs': '跨度'
      },
      {
        'zuxhzhs': '组选和值',
        'sxzuxzsh': '组3',
        'sxzuxzlh': '组6',
        'sxhhzxh': '混合组选',
        'zuxhsbd': '组选包胆',
        'hszsds': '组三单式',
        'hszlds': '组六单式'
      },{
        'bdwhs': '一码不定位',
        'bdwhs2m': '二码不定位'
      }
    ];
   // 前二/后二字段
  var ssc_q2_arr = [
    {
      'exzhixfsq': '直选复式',
      'exzhixdsq': '直选单式',
      'zhixhzqe': '直选和值',
      'kuaduqe': '跨度'
    },
    {
      'exzuxfsq': '组选复式',
      'exzuxdsq': '组选单式',
      'zuxhzqe': '组选和值',
      'zuxcebd': '组选包胆'
    }
  ];
  //后二
  var ssc_h2_arr = [
    {
      'exzhixfsh': '直选复式',
      'exzhixdsh': '直选单式',
      'zhixhzhe': '直选和值',
      'kuaduhe': '跨度'
    },
    {
      'exzuxfsh': '组选复式',
      'exzuxdsh': '组选单式',
      'zuxhzhe': '组选和值',
      'zuxhebd': '组选包胆'
    }
  ];
  var q2_exzhixfs = ['万位','千位'];
  var h2_exzhixfs = ['十位','个位'];
  var ex_exzhixdsh = ['和值'];
  var ex_kuaduhe = ['跨度'];
  var ex_exzuxfsh = ['组选'];
  var ex_zsxhz = ['和值'];
  var ex_zsxbd = ['包胆'];
  var ssc_q2_title = ['直选','组选'];
  // 一星字段
  var ssc_1x_arr = [
    {
      'dweid': '复式'
    }
  ];
  var ssc_1x_title = ['定位胆'];
   // 大小单双字段
  var ssc_dsds_arr = [
    {
      'dxdsqe': '前二',
      'dxdshe': '后二',
      'dxdsqs': '前三',
      'dxdshs': '后三',
    }
  ];
  var ssc_dsds_title = ['大小单双'];
  var dxdsqe = ['万位','千位'];
  var dxdshe = ['十位','个位'];
  var dxdsqs = ['万位','千位','百位'];
  var dxdshs = ['百位','十位','个位'];
  //时时彩结束
  //北京pk10开始
  //定位胆
  var bjpks_dwd_arr = [
    {
      'bjpk10dwd': '定位胆'
    }
  ];
  var bjpks_dwd_title = ['标准'];
  var bjpks_dwd = ['冠军','亚军','季军','第四','第五','第六','第七','第八','第九','第十'];
  //猜前五
  var bjpks_cqw_arr = [
    {
      'bjpk10qian5': '复式',
      'bjpk10qian5ds': '单式'
    }
  ];
  var bjpks_cqw_title = ['直选'];
  var bjpks_cqw = ['冠军','亚军','季军','第四','第五'];
  //猜前四
  var bjpks_cqs_arr = [
    {
      'bjpk10qian4': '复式',
      'bjpk10qian4ds': '单式'
    }
  ];
  var bjpks_cqs_title = ['直选'];
  var bjpks_cqs = ['冠军','亚军','季军','第四'];
  //猜前三
  var bjpks_cqsan_arr = [
    {
      'bjpk10qian3': '复式',
      'bjpk10qian3ds': '单式'
    }
  ];
  var bjpks_cqsan_title = ['直选'];
  var bjpks_cqsan = ['冠军','亚军','季军'];
  //猜前二
  var bjpks_cqe_arr = [
    {
      'bjpk10qian2': '复式',
      'bjpk10qian2ds': '单式'
    }
  ];
  var bjpks_cqe_title = ['直选'];
  var bjpks_cqe = ['冠军','亚军'];
  //猜冠军
  var bjpks_cqgj_arr = [
    {
      'bjpk10qian1': '复式'
    }
  ];
  var bjpks_cqgj_title = ['直选'];
  var bjpks_cqgj = ['冠军'];
  //北京pk10结束
  //北京快乐8开始
  //任选
  var kl8_rx = [
    {
      'bjkl8rx1': '任选一',
      'bjkl8rx2': '任选二',
      'bjkl8rx3': '任选三',
      'bjkl8rx4': '任选四',
      'bjkl8rx5': '任选五',
      'bjkl8rx6': '任选六',
      'bjkl8rx7': '任选七'
    }
  ];
  var kl8_rx_title = ['普通玩法'];
  var kl8_bjkl8rx1 = ['上盘','下盘'];
  //趣味
  var kl8_qw = [
    {
      'bjkl8sxp': '上下盘',
      'bjkl8jop': '奇偶盘',
      'bjkl8dxds': '和值大小单双'
    }
  ];
  var kl8_qw_title = ['标准'];
  var kl8_bjkl8sxp = {
    '0': '上',
    '1': '中',
    '2': '下'
  };
  var kl8_bjkl8jop = {
    '0': '奇',
    '1': '和',
    '2': '偶',
  };
  var kl8_bjkl8dxds = {
    '0': '大单',
    '1': '大双',
    '2': '小单',
    '3': '小双'
  }
  //北京快乐8结束
  //11选5开始
  //三码
  var syxw_sm = [
    {
      'x5qsfs': '前三直选复式',
      'x5qsds': '前三直选单式',
      'x5qszx': '前三组选复式',
      'x5qszxds': '前三组选单式',
      'x5qsdt': '前三组选胆拖',
    }
  ];
  var syxw_sm_title = ['三码'];
  var syxw_x5qsfs = ['第一位','第二位','第三位'];
  var syxw_x5qszx = ['前三组选'];
  var syxw_x5qsdt = ['胆码','拖码'];
  //二码
  var syxw_em = [
    {
      'x5qefs': '前二直选复式',
      'x5qeds': '前二直选单式',
      'x5qezx': '前二组选复式',
      'x5qezxds': '前二组选单式',
      'x5qedt': '前二组选胆拖',
    }
  ];
  var syxw_em_title = ['二码'];
  var syxw_x5qefs = ['第一位','第二位'];
  var syxw_x5qezx = ['前二组选'];
  var syxw_x5qedt = ['胆码','拖码'];
  //不定位
  var syxw_qsymbdw = [
    {
      'x5bdwqs': '前三一码不定位'
    }
  ];
  var syxw_qsymbdw_title = ['不定位'];
  var syxw_x5bdwqs = ['不定位'];
  //定位胆
  var syxw_dwd = [
    {
      'x5dwd': '复式'
    }
  ];
  var syxw_dwd_title = ['定位胆'];
  var syxw_x5dwd = ['第一位','第二位','第三位'];
  //趣味型
  var syxw_qwx = [
    {
      'x5dds': '定单双',
      'x5czw': '猜中位'
    }
  ];
  var syxw_qwx_title = ['趣味型'];
  var syxw_x5czw = ['猜中位'];
  var syxw_x5dds = {
    '0': '5单0双',
    '1': '4单1双',
    '2': '3单2双',
    '3': '2单3双',
    '4': '1单4双',
    '5': '0单5双'
  };
  //任选复式
  var syxw_rxfs = [
    {
      'x5rx1z1': '一中一',
      'x5rx2z2': '二中二',
      'x5rx3z3': '三中三',
      'x5rx4z4': '四中四',
      'x5rx5z5': '五中五',
      'x5rx6z5': '六中五',
      'x5rx7z5': '七中五',
      'x5rx8z5': '八中五'
    }
  ];
  var syxw_rxfs_title = ['任选复式'];
  var syxw_x5rx1z1 = ['选一中一'];
  var syxw_x5rx2z2 = ['选二中二'];
  var syxw_x5rx3z3 = ['选三中三'];
  var syxw_x5rx4z4 = ['选四中四'];
  var syxw_x5rx5z5 = ['选五中五'];
  var syxw_x5rx6z5 = ['选六中五'];
  var syxw_x5rx7z5 = ['选七中五'];
  var syxw_x5rx8z5 = ['选八中五'];
  //任选单式
  var syxw_rxds = [
    {
      'x5rxds1z1': '一中一',
      'x5rxds2z2': '二中二',
      'x5rxds3z3': '三中三',
      'x5rxds4z4': '四中四',
      'x5rxds5z5': '五中五',
      'x5rxds6z5': '六中五',
      'x5rxds7z5': '七中五',
      'x5rxds8z5': '八中五'
    }
  ];
  var syxw_rxds_title = ['任选单式'];
  //任选拖胆
  var syxw_rxtd = [
    {
      'x5dt2z2': '二中二',
      'x5dt3z3': '三中三',
      'x5dt4z4': '四中四',
      'x5dt5z5': '五中五',
      'x5dt6z5': '六中五',
      'x5dt7z5': '七中五',
      'x5dt8z5': '八中五',
    }
  ];
  var syxw_rxtd_title = ['任选拖胆'];
  var syxw_rxtd_x5dt2z2 = ['胆码','拖码'];
  //11选5结束
  //福彩3D
  //三星
  var fc3d_3x_arr = [
    {
      'pl3zxfs': '直选复式',
      'pl3zxds': '直选单式',
      'pl3hzzx': '直选和值',
      'pl3kd': '跨度'
    },
    {
      'pl3zuxhz': '组选和值',
      'pl3zux3': '组3',
      'pl3zux6': '组6',
      'pl3zuxhh': '混合组选',
      'pl3zuxbd': '组选包胆',
      'pl3zsds': '组三单式',
      'pl3zlds': '组六单式'
    },{
      'pl3ymbdw': '一码不定位',
      'pl3rmbdw': '二码不定位'
    }
  ];
  var fc3d_3x_title = ['直选','组选','不定位']; 
  var fc3d_3x_sxzhixfsq = ['百位','十位','个位'];
  var fc3d_3x_zhixhzqs = ['和值'];
  var fc3d_3x_kuaduqs = ['跨度'];
  var fc3d_3x_sxzuxzsq = ['组3'];
  var fc3d_3x_sxzuxzlq = ['组6'];
  var fc3d_3x_zuxcsbd = ['包胆'];
  var fc3d_3x_bdw = ['不定位'];
  // 前二
  var fc3d_qe_arr = [
    {
      'pl3qx2fs': '直选复式',
      'pl3qx2ds': '直选单式',
      'pl3q2zxhz': '直选和值',
      'pl3q2kd': '跨度'
    },
    {
      'pl3q2zxfs': '组选复式',
      'pl3q2zxds': '组选单式',
      'pl3q2zuxhz': '组选和值',
      'pl3q2zxbd': '组选包胆'
    }
  ];
  //后二
  var fc3d_he_arr = [
    {
      'pl3hx2fs': '直选复式',
      'pl3hx2ds': '直选单式',
      'pl3h2zxhz': '直选和值',
      'pl3h2kd': '跨度'
    },
    {
      'pl3h2zxfs': '组选复式',
      'pl3h2zxds': '组选单式',
      'pl3h2zuxhz': '组选和值',
      'pl3h2zxbd': '组选包胆'
    }
  ];
  var fc3d_q2_exzhixfs = ['万位','千位'];
  var fc3d_h2_exzhixfs = ['十位','个位'];
  var fc3d_ex_exzhixdsh = ['和值'];
  var fc3d_ex_kuaduhe = ['跨度'];
  var fc3d_ex_exzuxfsh = ['组选'];
  var fc3d_ex_zsxhz = ['和值'];
  var fc3d_ex_zsxbd = ['包胆'];
  var fc3d_q2_title = ['直选','组选'];
  // 一星字段
  var fc3d_1x_arr = [
    {
      'pl3dwdfs': '复式'
    }
  ];
  var fc3d_1x_title = ['定位胆'];
  var fc3d_1x_fs = ['百位','十位','个位'];
   // 大小单双字段
  var fc3d_dsds_arr = [
    {
      'dxdsq2': '前二大小单双',
      'dxdsh2': '后二大小单双',
    }
  ];
  var ssc_dsds_title = ['大小单双'];
  var fc3d_dxds_qe = ['百位','十位'];
  var fc3d_dxds_he = ['十位','个位'];
  //福彩3D结束
  //排列3
  //三星
  var pl3_3x_arr = [
    {
      'pl3zxfs': '直选复式',
      'pl3zxds': '直选单式',
      'pl3hzzx': '直选和值',
      'pl3kd': '跨度'
    },
    {
      'pl3zuxhz': '组选和值',
      'pl3zux3': '组3',
      'pl3zux6': '组6',
      'pl3zuxhh': '混合组选',
      'pl3zuxbd': '组选包胆',
      'pl3zsds': '组三单式',
      'pl3zlds': '组六单式'
    },{
      'pl3ymbdw': '一码不定位',
      'pl3rmbdw': '二码不定位'
    }
  ];
  var pl3_3x_title = ['直选','组选','不定位']; 
  var pl3_3x_sxzhixfsq = ['百位','个位','十位'];
  var pl3_3x_zhixhzqs = ['和值'];
  var pl3_3x_kuaduqs = ['跨度'];
  var pl3_3x_sxzuxzsq = ['组3'];
  var pl3_3x_sxzuxzlq = ['组6'];
  var pl3_3x_zuxcsbd = ['包胆'];
  var pl3_3x_bdw = ['不定位'];
  // 前二
  var pl3_qe_arr = [
    {
      'pl3qx2fs': '直选复式',
      'pl3qx2ds': '直选单式',
      'pl3q2zxhz': '直选和值',
      'pl3q2kd': '跨度'
    },
    {
      'pl3q2zxfs': '组选复式',
      'pl3q2zxds': '组选单式',
      'pl3q2zuxhz': '组选和值',
      'pl3q2zxbd': '组选包胆'
    }
  ];
  //后二
  var pl3_he_arr = [
    {
      'pl3hx2fs': '直选复式',
      'pl3hx2ds': '直选单式',
      'pl3h2zxhz': '直选和值',
      'pl3h2kd': '跨度'
    },
    {
      'pl3h2zxfs': '组选复式',
      'pl3h2zxds': '组选单式',
      'pl3h2zuxhz': '组选和值',
      'pl3h2zxbd': '组选包胆'
    }
  ];
  var pl3_q2_exzhixfs = ['万位','千位'];
  var pl3_h2_exzhixfs = ['十位','个位'];
  var pl3_ex_exzhixdsh = ['和值'];
  var pl3_ex_kuaduhe = ['跨度'];
  var pl3_ex_exzuxfsh = ['组选'];
  var pl3_ex_zsxhz = ['和值'];
  var pl3_ex_zsxbd = ['包胆'];
  var pl3_q2_title = ['直选','组选'];
  // 一星字段
  var pl3_1x_arr = [
    {
      'pl3dwdfs': '复式'
    }
  ];
  var pl3_1x_title = ['定位胆'];
  var pl3_1x_fs = ['百位','十位','个位'];
   // 大小单双字段
  var pl3_dsds_arr = [
    {
      'dxdsq2': '前二大小单双',
      'dxdsh2': '后二大小单双',
    }
  ];
  var ssc_dsds_title = ['大小单双'];
  var pl3_dxds_qe = ['百位','十位'];
  var pl3_dxds_he = ['十位','个位'];
  //排列3结束

  //六合彩对应数据
  var lhc_numData = {
    'lhc_01': {
      'bo': 'red',
      'sx': '鸡'
    },
    'lhc_02': {
      'bo': 'red',
      'sx': '猴'
    },
    'lhc_03': {
      'bo': 'blue',
      'sx': '羊'
    },
    'lhc_04': {
      'bo': 'blue',
      'sx': '马'
    },
    'lhc_05': {
      'bo': 'green',
      'sx': '蛇'
    },
    'lhc_06': {
      'bo': 'green',
      'sx': '龙'
    },
    'lhc_07': {
      'bo': 'red',
      'sx': '兔'
    },
    'lhc_08': {
      'bo': 'red',
      'sx': '虎'
    },
    'lhc_09': {
      'bo': 'blue',
      'sx': '牛'
    },
    'lhc_10': {
      'bo': 'blue',
      'sx': '鼠'
    },
    'lhc_11': {
      'bo': 'green',
      'sx': '猪'
    },
    'lhc_12': {
      'bo': 'red',
      'sx': '狗'
    },
    'lhc_13': {
      'bo': 'red',
      'sx': '鸡'
    },
    'lhc_14': {
      'bo': 'blue',
      'sx': '猴'
    },
    'lhc_15': {
      'bo': 'blue',
      'sx': '羊'
    },
    'lhc_16': {
      'bo': 'green',
      'sx': '马'
    },
    'lhc_17': {
      'bo': 'green',
      'sx': '蛇'
    },
    'lhc_18': {
      'bo': 'red',
      'sx': '龙'
    },
    'lhc_19': {
      'bo': 'red',
      'sx': '兔'
    },
    'lhc_20': {
      'bo': 'blue',
      'sx': '虎'
    },
    'lhc_21': {
      'bo': 'green',
      'sx': '牛'
    },
    'lhc_22': {
      'bo': 'green',
      'sx': '鼠'
    },
    'lhc_23': {
      'bo': 'red',
      'sx': '猪'
    },
    'lhc_24': {
      'bo': 'red',
      'sx': '狗'
    },
    'lhc_25': {
      'bo': 'blue',
      'sx': '鸡'
    },
    'lhc_26': {
      'bo': 'blue',
      'sx': '猴'
    },
    'lhc_27': {
      'bo': 'green',
      'sx': '羊'
    },
    'lhc_28': {
      'bo': 'green',
      'sx': '马'
    },
    'lhc_29': {
      'bo': 'red',
      'sx': '蛇'
    },
    'lhc_30': {
      'bo': 'red',
      'sx': '龙'
    },
    'lhc_31': {
      'bo': 'blue',
      'sx': '兔'
    },
    'lhc_32': {
      'bo': 'green',
      'sx': '虎'
    },
    'lhc_33': {
      'bo': 'green',
      'sx': '牛'
    },
    'lhc_34': {
      'bo': 'red',
      'sx': '鼠'
    },
    'lhc_35': {
      'bo': 'red',
      'sx': '猪'
    },
    'lhc_36': {
      'bo': 'blue',
      'sx': '狗'
    },
    'lhc_37': {
      'bo': 'blue',
      'sx': '鸡'
    },
    'lhc_38': {
      'bo': 'green',
      'sx': '猴'
    },
    'lhc_39': {
      'bo': 'green',
      'sx': '羊'
    },
    'lhc_40': {
      'bo': 'red',
      'sx': '马'
    },
    'lhc_41': {
      'bo': 'blue',
      'sx': '蛇'
    },
    'lhc_42': {
      'bo': 'blue',
      'sx': '龙'
    },
    'lhc_43': {
      'bo': 'green',
      'sx': '兔'
    },
    'lhc_44': {
      'bo': 'green',
      'sx': '虎'
    },
    'lhc_45': {
      'bo': 'red',
      'sx': '牛'
    },
    'lhc_46': {
      'bo': 'red',
      'sx': '鼠'
    },
    'lhc_47': {
      'bo': 'blue',
      'sx': '猪'
    },
    'lhc_48': {
      'bo': 'blue',
      'sx': '狗'
    },
    'lhc_49': {
      'bo': 'green',
      'sx': '鸡'
    },
  }