<include file="Public/header" />
<link rel="stylesheet" href="__CSS__/activity.css">

</head>
<body class="bg_fff">
	<header data-am-widget="header"class="am-header am-header-default header nav_bg am-header-fixed">
		<div class="am-header-left am-header-nav">
			<a href="javascript:history.back(-1);" class="">
				<i class="iconfont icon-arrow-left"></i>
			</a>
      	</div>

		<h1 class="am-header-title activity_h1">
			晋级奖励
		</h1>
	</header>
	<div class="promotion_main">
	<h2 class="promotion_h2">
				活动说明
			</h2>
	<p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">尊敬的各位会员：您好！针对近期<span style="box-sizing:inherit; margin:0px auto; padding:0px;">使用微信、支付宝充值<span style="box-sizing:inherit; margin:0px auto; padding:0px;">时</span></span>部分会员出现限额、异常等情况。</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);"><br></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);">福利彩平台推荐您使用“手机银行/网银转账到银行卡/支付宝转账到银行卡/微信转账转账到银行卡”的充值方式</span><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);">，单笔<span style="box-sizing:inherit; margin:0px auto; padding:0px;">充值1000以上，还能赠送1%存款红利。</span></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);"><span style="box-sizing:inherit; margin:0px auto; padding:0px;"></span></span><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(0, 0, 0);"><br></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(0, 0, 0);">直接转账到银行卡充值：即时到账，简单、快捷。</span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(0, 0, 0);"></span><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(0, 0, 0);"><br></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(0, 0, 0);">充值步骤如下：</span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);"><br></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);">1、登录会员账号后，点击充值-银行卡转账，获取到专属的收款卡号。</span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);"><br></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);">2、打开手机银行或者电脑 的银行客户端，点击首页中的“转账”，输入姓名、卡号、选择银行、输入您的转账金额，点击下一步确定转账信息，并且成功转账。</span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);"><br></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);">3.支付宝</span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);"><br></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);"><img src="//bmvrde.img48.wal8.com/img48/17288782_20180427175156/152492853516.png" width="780" height="1310"></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);">4.微信</span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);"><br></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; margin:0px auto; padding:0px; color:rgb(255, 0, 0);"><img src="//bmvrde.img48.wal8.com/img48/17288782_20180427175156/152492853421.png" width="780" height="1310"></span></p><p style="margin-right:auto; margin-left:auto; box-sizing:inherit; font-family:Helvetica, arial, sans-serif; padding:0px; color:rgb(92, 92, 92); background-color:rgb(255, 255, 255); font-size:14px !important;"><br></p><p style="margin-right:auto; margin-left:auto; box-sizing:inherit; font-family:Helvetica, arial, sans-serif; padding:0px; color:rgb(92, 92, 92); background-color:rgb(255, 255, 255); font-size:14px !important;">为了您的款项能即时到账，转账时记得备注您的会员账号。您若不懂操作转账，请及时联系我们的在线客服进行操作咨询。感谢您长久以来对“福利彩”的支持与信赖，福利彩平台也将会尽力改善充值问题，祝您游戏愉快、盈利多多！</p><p><br></p>
	</div>

	<include file="Public/footer" />
	<script type="text/javascript">
		function jiangli(){
			$.post("{:U('Activity/jinji')}",'', function(json){
				if(json.status==1){
					alert(json.info);
					window.location.reload();
				}else{
					alert(json.info);
				}
			},'json');
			return false;
		}
	</script>
</body>
</html>