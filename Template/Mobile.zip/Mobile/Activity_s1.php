<include file="Public/header" />
<link rel="stylesheet" href="__CSS__/activity.css">

</head>
<body class="bg_fff">
	<header data-am-widget="header"class="am-header am-header-default header nav_bg am-header-fixed">
		<div class="am-header-left am-header-nav">
			<a href="javascript:history.back(-1);" class="">
				<i class="iconfont icon-arrow-left"></i>
			</a>
      	</div>

		<h1 class="am-header-title activity_h1">
			晋级奖励
		</h1>
	</header>
	<div class="promotion_main">
	<h2 class="promotion_h2">
				活动说明
			</h2>
		<p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; font-weight:bolder;"><span style="box-sizing:inherit; color:rgb(192, 0, 0);">奖规则：</span></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; font-weight:bolder;"><span style="box-sizing:inherit; color:rgb(192, 0, 0);">额外轮盘次数增加方法：</span></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; font-weight:bolder;"><span style="box-sizing:inherit; color:rgb(192, 0, 0);">方法一：当日新增一个下级首充36元以上，可申请一次抽奖机会：当日新增N个下级首充36元以上，日可申请N次抽奖机会，无上限！</span></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; font-weight:bolder;"><span style="box-sizing:inherit; color:rgb(192, 0, 0);">方法二：当天使用网银第一笔充值1000元，可申请1次抽奖机会；充值5000元，2次；充值10000元，3次；充值50000元，4次；充值100000元，5次。此方法可与网银充值入款笔笔存笔笔送1%奖金共享，无上限！</span></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; font-weight:bolder;"><span style="box-sizing:inherit; color:rgb(192, 0, 0);"><span style="box-sizing:inherit; color:rgb(250, 192, 143);">（<span style="box-sizing:inherit; color:rgb(192, 0, 0);">代理福利专员QQ：<span style="box-sizing:inherit; color:rgb(255, 0, 0);"><span style="color:rgb(255, 0, 0); font-family:&quot;Microsoft YaHei&quot;; font-size:14px; background-color:rgb(255, 255, 255);">574289280</span>；<span style="box-sizing:inherit; font-weight:bolder;"><span style="box-sizing:inherit; color:rgb(192, 0, 0);">微信</span></span><span style="box-sizing:inherit; font-weight:bolder;"><span style="box-sizing:inherit; color:rgb(192, 0, 0);"><span style="box-sizing:inherit; color:rgb(250, 192, 143);"><span style="box-sizing:inherit; color:rgb(192, 0, 0);">：<span style="box-sizing:inherit; color:rgb(255, 0, 0);"><span style="color:rgb(255, 0, 0); font-family:&quot;Microsoft YaHei&quot;; font-size:14px; background-color:rgb(255, 255, 255);">zxt68zxt</span></span></span></span></span></span></span>）</span><span style="box-sizing:inherit; color:rgb(255, 0, 0);"></span></span></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">1、北京时间00:00到次日24:00，凡在福利彩票当天使用网银充值1000元以上均可参与抽奖，百分百中奖最高奖金1888元。使用网银充值1000元以上获一次抽奖资格，使用网银充值5000元以上获两次抽奖资格，使用网银充值10000元以上获三次抽奖资格，使用网银充值50000元以上获四次抽奖资格，使用网银充值100000元以上获五次抽奖资格！百分百中奖，最高奖金1888元，千万巨资回馈幸运玩家！</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">2、当日网银充值计算周期北京时间进行计算，即北京时间每天早上0点至隔天早上24点；</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">3、如果您的当日网银充值达到抽奖条件，即可在当天北京时间20:00后开始抽奖，且需在当天完成抽奖，否则视为放弃活动资格；</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">4、每位会员每个IP当日累计抽奖次数最多为16次，如发现会员同一个IP下注册多个账号进行投注抽奖，公司有权拒绝赠送其彩金并做账号冻结处理，保证正常玩家的利益；</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">5、获得“现金筹码”的1倍流水才能出款，获得“现金筹码”的会员无需申请，系统将在24小时内自动添加到您的会员账户内，请耐心等待；（注：当会员抽取“现金筹码”奖项，如若需放弃请联系在线客服进行处理，否则将视为您同意抽奖条件。)</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">6、此转盘活动为【福利彩票】系统程序自动运行，获奖的概率完全遵循力学及自然概率，不涉及任何人工操作，抽奖结果以系统判定为准，不得争议。</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">活动声明：</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">1、所有红利为随机派送, 如系统发生一些不可预测超出本站控制之外的技术错误, 或人为不可控制的因素, 则福利彩票保留最终处理权；</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">2、玩家不可以使用多账户参加本次活动，凡同一IP地址、同一姓名、同一银行账户，同一联系方式，同一邮箱、同一电脑均视为同一账户，“福利彩票”在会员重复申请会员账号时，保留取消、收回会员相关优惠 ；</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">3、无论是个人或团体，如有任何威胁、滥用或使用不诚实方式套利的行为，经“福利彩票”风险部门审核，公司有权取消该会员所有优惠；</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">4、本活动最终解释权归属“福利彩票”所有，并保留修改以上条款的最终权利。</p><p><br></p>
	</div>

	<include file="Public/footer" />
	<script type="text/javascript">
		function jiangli(){
			$.post("{:U('Activity/jinji')}",'', function(json){
				if(json.status==1){
					alert(json.info);
					window.location.reload();
				}else{
					alert(json.info);
				}
			},'json');
			return false;
		}
	</script>
</body>
</html>