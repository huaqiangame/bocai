<div class="update_header am-modal-actions"  id="my-actions">
    <div class="update_header_title am-cf">
        <h3 class="am-fl">修改头像</h3>
        <i class="iconfont icon-cross-ivt am-fr" data-am-modal-close></i>
    </div>
    <div class="update_header_main">
        <span class="preview am-block">预览</span>
        <div class="img"><img class="update_header_img" src="__FACE__/1.jpg" alt=""></div>
        <em class="update_header_name am-block">奥巴马</em>
        <div class="update_header_list">
            <div class="prev"><i class="am-datepicker-prev-icon"></i></div>
            <div class="update_header_imgs_box">
                <div class="update_header_imgs am-cf" id="update_header_imgs">
                    <img class="update_header_watch" src="__FACE__/1.jpg" alt="奥巴马">
                    <img class="update_header_watch" src="__FACE__/2.jpg" alt="小女孩">
                    <img class="update_header_watch" src="__FACE__/3.jpg" alt="泷泽萝拉">
                    <img class="update_header_watch" src="__FACE__/4.jpg" alt="科比"> 
                    <img class="update_header_watch" src="__FACE__/5.jpg" alt="金正恩">
                    <img class="update_header_watch" src="__FACE__/6.jpg" alt="杰森斯坦森">
                    <img class="update_header_watch" src="__FACE__/8.jpg" alt="梅西">
                    <img class="update_header_watch" src="__FACE__/7.jpg" alt="范冰冰">
                    <img class="update_header_watch" src="__FACE__/9.jpg" alt="本拉登">
                    <img class="update_header_watch" src="__FACE__/10.jpg" alt="萨达姆">
                    <img class="update_header_watch" src="__FACE__/11.jpg" alt="宋慧乔">
                    <img class="update_header_watch" src="__FACE__/12.jpg" alt="李敏镐">
                    <img class="update_header_watch" src="__FACE__/13.jpg" alt="宋仲基">
                    <img class="update_header_watch" src="__FACE__/14.jpg" alt="比尔盖茨">
                    <img class="update_header_watch" src="__FACE__/15.jpg" alt="罗纳尔多">
                    <img class="update_header_watch" src="__FACE__/16.jpg" alt="宋承宪">
                    <img class="update_header_watch" src="__FACE__/17.jpg" alt="小男孩">
                    <img class="update_header_watch" src="__FACE__/18.jpg" alt="朴信惠">
                    <img class="update_header_watch" src="__FACE__/19.jpg" alt="希拉里">
                    <img class="update_header_watch" src="__FACE__/20.jpg" alt="全智贤">
                    <img class="update_header_watch" src="__FACE__/21.jpg" alt="林允儿">
                    <img class="update_header_watch" src="__FACE__/22.jpg" alt="普京">
                    <img class="update_header_watch" src="__FACE__/23.jpg" alt="波多野结衣">
                    <img class="update_header_watch" src="__FACE__/24.jpg" alt="贝克汉姆">
                    <img class="update_header_watch" src="__FACE__/25.jpg" alt="苍井空">
                </div>
            </div>
            <div class="next"><i class="am-datepicker-next-icon"></i></div>
        </div>
    </div>
    <div class="update_header_bottom">
        <button class="am-btn am-btn-default am-radius btn_red save saveface" data-am-modal-close>确定</button>
        <button class="am-btn am-btn-default am-radius close" style="background-color: #828282;" data-am-modal-close>取消</button>
    </div>
</div>
