<include file="Public/header" />
<link rel="stylesheet" href="__CSS__/activity.css">

</head>
<body class="bg_fff">
	<header data-am-widget="header"class="am-header am-header-default header nav_bg am-header-fixed">
		<div class="am-header-left am-header-nav">
			<a href="javascript:history.back(-1);" class="">
				<i class="iconfont icon-arrow-left"></i>
			</a>
      	</div>

		<h1 class="am-header-title activity_h1">
			晋级奖励
		</h1>
	</header>
	<div class="promotion_main">
	<h2 class="promotion_h2">
				活动说明
			</h2>
	<p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">当您能看到这个页面，说明您的账号既是玩家账号也是代理账号，既可以自己投注，也可以发展下级玩家，赚取返点佣金。</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><br></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; color:rgb(63, 63, 63);">所有代理请勿随意设置邀请码，有可能获取不到返点哦！</span><br></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; color:rgb(255, 0, 0);"><span style="box-sizing:inherit;"><span style="box-sizing:inherit;">代理咨询</span><span style="box-sizing:inherit;">QQ：574289280</span></span></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><br></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; color:rgb(255, 0, 0);">如何赚取返点？</span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">可获得的返点，等于自身返点与下级返点的差值，如自身返点5，下级返点3，你将能获得下级投注金额2%的返点，如下级投注100元，你将会获得2元。点击下级开户，可查看自身返点，也可为下级设置返点。</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><br></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; color:rgb(255, 0, 0);">如何为下级开户？</span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">点击下级开户，先为您的下级设置返点，设置成功后会生成一条邀请码，将邀请码发送给您的下级注册，注册后他就是您的下级，点击会员管理，就能查看他注册的账号；</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">如果您为下级设置的是代理类型的账号，那么您的下级就能继续发展下级，如果设置的是玩家类型，那么您的下级只能投注，不能再发展下级，也看不到代理中心；</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><br></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; color:rgb(255, 0, 0);">返点何时结算？</span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; color:rgb(63, 63, 63);">不是月结也不是日结，是现结！您的下级每次下注，您即可获取返点，返点在您的会员账户里面查看。</span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; color:rgb(12, 12, 12);"><br></span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><span style="box-sizing:inherit; color:rgb(255, 0, 0);">温馨提示：</span></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">&nbsp;返点不同赔率也不同，点击返点赔率表，可查看返点赔率；</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><br></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">&nbsp;返点越低，赔率就越低，建议为下级设置的返点不要过低；</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><br></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">&nbsp;可在代理报表、投注明细、交易明细查看代理的发展情况；</p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;"><br></p><p style="box-sizing:inherit; font-family:&quot;Microsoft YaHei&quot;; color:rgb(102, 102, 102); background-color:rgb(255, 255, 255); font-size:14px !important; padding:0px !important;">&nbsp;建议开设的下级也是代理类型，无论发展了几级，您都能获得返点。</p><p><br></p>
	</div>

	<include file="Public/footer" />
	<script type="text/javascript">
		function jiangli(){
			$.post("{:U('Activity/jinji')}",'', function(json){
				if(json.status==1){
					alert(json.info);
					window.location.reload();
				}else{
					alert(json.info);
				}
			},'json');
			return false;
		}
	</script>
</body>
</html>