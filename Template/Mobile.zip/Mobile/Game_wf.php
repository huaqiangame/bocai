<script type="text/html" id="k3hzzx_wf">
	<!--和值-->

	<div id="k3hzzx" class="ball_section section_cqssc">
		<p class="remark" style="text-align:center;color:#999;margin:15px 0 5px;color:#caebda;">
			猜3个开奖号相加的和,3-10为小,11-18为大
		</p>
		<div class="li_ball">
			<div class="ui-row-flex">
				<div class="ui-col ui-col-4 line-box">
					<ul class="ball_list_ul">
						<li class="ball_item"><a playid="k3hzbig" ball-type="k3hzzx" ball-number="大" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hzbig}"><b>大</b>
								<p class="peilv">
									赔率{$peilv.k3hzbig}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hzsmall" ball-type="k3hzzx" ball-number="小" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hzsmall}"><b>小</b>
								<p class="peilv">
									赔率{$peilv.k3hzsmall}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hzodd" ball-type="k3hzzx" ball-number="单" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hzodd}"><b>单</b>
								<p class="peilv">
									赔率{$peilv.k3hzodd}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hzeven" ball-type="k3hzzx" ball-number="双" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hzeven}"><b>双</b>
								<p class="peilv">
									赔率{$peilv.k3hzeven}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz3" ball-type="k3hzzx" ball-number="3" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz3}"><b>3</b>
								<p class="peilv">
									赔率{$peilv.k3hz3}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz4" ball-type="k3hzzx" ball-number="4" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz4}"><b>4</b>
								<p class="peilv">
									赔率{$peilv.k3hz4}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz5" ball-type="k3hzzx" ball-number="5" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz5}"><b>5</b>
								<p class="peilv">
									赔率{$peilv.k3hz5}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz6" ball-type="k3hzzx" ball-number="6" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz6}"><b>6</b>
								<p class="peilv">
									赔率{$peilv.k3hz6}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz7" ball-type="k3hzzx" ball-number="7" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz7}"><b>7</b>
								<p class="peilv">
									赔率{$peilv.k3hz7}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz8" ball-type="k3hzzx" ball-number="8" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz8}"><b>8</b>
								<p class="peilv">
									赔率{$peilv.k3hz8}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz9" ball-type="k3hzzx" ball-number="9" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz9}"><b>9</b>
								<p class="peilv">
									赔率{$peilv.k3hz9}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz10" ball-type="k3hzzx" ball-number="10" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz10}"><b>10</b>
								<p class="peilv">
									赔率{$peilv.k3hz10}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz11" ball-type="k3hzzx" ball-number="11" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz11}"><b>11</b>
								<p class="peilv">
									赔率{$peilv.k3hz11}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz12" ball-type="k3hzzx" ball-number="12" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz12}"><b>12</b>
								<p class="peilv">
									赔率{$peilv.k3hz12}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz13" ball-type="k3hzzx" ball-number="13" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz13}"><b >13</b>
								<p class="peilv">
									赔率{$peilv.k3hz13}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz14" ball-type="k3hzzx" ball-number="14" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz14}"><b>14</b>
								<p class="peilv">
									赔率{$peilv.k3hz14}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz15" ball-type="k3hzzx" ball-number="15" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz15}"><b>15</b>
								<p class="peilv">
									赔率{$peilv.k3hz15}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz16" ball-type="k3hzzx" ball-number="16" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz16}"><b>16</b>
								<p class="peilv">
									赔率{$peilv.k3hz16}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz17" ball-type="k3hzzx" ball-number="17" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz17}"><b>17</b>
								<p class="peilv">
									赔率{$peilv.k3hz17}
								</p>
							</a></li>
						<li class="ball_item"><a playid="k3hz18" ball-type="k3hzzx" ball-number="18" href="javascript:void(0)" class="ball_number" peilv="{$peilv.k3hz18}"><b>18</b>
								<p class="peilv">
									赔率{$peilv.k3hz18}
								</p>
							</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>

</script>
<script type="text/html" id="k3sthtx_wf">
	<!--三同号通选-->

	<div id="k3sthtx" class="ball_section section_cqssc">
		<p class="remark" style="color:#999">
			对所有相同的三个号码（111、222、333、444、555、666）进行投注，任意号码开出，即为中奖。奖金<var class="tpl">{$peilv.k3sthtx}</var>倍
		</p>
		<div class="li_ball">
			<div class="ui-row-flex">
				<div class="ui-col ui-col-4 line-box">
					<ul class="ball_list_ul">
						<li style="width:100%" class="ball_item"><a playid="k3sthtx" playid="k3sthtx" href="javascript:void(0);" ball-type="3THTX" ball-number="三同号通选" class="ball_number" id="slhtx_btn"><b>三同号通选</b></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>

</script>
<script type="text/html" id="k3sthdx_wf">
	<!--3同号单选-->
	<div id="k3sthdx" class="ball_section section_cqssc">
		<p class="remark" style="color:#999">
			对相同的三个号码（111、222、333、444、555、666）中的任意一个进行投注，所选号码开出，即为中奖。奖金<var class="tpl">{$peilv.k3sthdx}</span>倍
		</p>
		<div class="li_ball">
			<div class="ui-row-flex">
				<div class="ui-col ui-col-4 line-box">
					<ul class="ball_list_ul">
						<li style="width:33.3%" class=" ball_item"><a playid="k3sthdx" ball-type="k3sthdx" ball-number="111" href="javascript:void(0)" class="ball_number"><b>111</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a playid="k3sthdx" ball-type="k3sthdx" ball-number="222" href="javascript:void(0)" class="ball_number"><b>222</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a playid="k3sthdx" ball-type="k3sthdx" ball-number="333" href="javascript:void(0)" class="ball_number"><b>333</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a playid="k3sthdx" ball-type="k3sthdx" ball-number="444" href="javascript:void(0)" class="ball_number"><b>444</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a playid="k3sthdx" ball-type="k3sthdx" ball-number="555" href="javascript:void(0)" class="ball_number"><b>555</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a playid="k3sthdx" ball-type="k3sthdx" ball-number="666" href="javascript:void(0)" class="ball_number"><b>666</b></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</script>
<script type="text/html" id="k3sbthbz_wf">
	<!--3不同号-->
	<div id="k3sbthbz" class="ball_section section_cqssc">
		<p class="remark" style="color:#999">
			从1～6中任选3个或多个号码，所选号码与开奖号码的3个号码相同，即为中奖。奖金<var class="tpl">{$peilv.k3sbthbz}</var>倍
		</p>
		<div class="li_ball">
			<div class="ui-row-flex">
				<div class="ui-col ui-col-4 line-box">
					<ul class="ball_list_ul">
						<li style="width:33.3%" class=" ball_item"><a playid="k3sbthbz" ball-type="k3sbthbz" ball-number="1" href="javascript:void(0)" class="ball_number"><b>1</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a playid="k3sbthbz" ball-number="2"  ball-type="k3sbthbz" href="javascript:void(0)" class="ball_number"><b>2</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a playid="k3sbthbz" ball-number="3" ball-type="k3sbthbz" href="javascript:void(0)" class="ball_number"><b>3</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a playid="k3sbthbz" ball-number="4" ball-type="k3sbthbz" href="javascript:void(0)" class="ball_number"><b>4</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a playid="k3sbthbz" ball-number="5" ball-type="k3sbthbz" href="javascript:void(0)" class="ball_number"><b>5</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a playid="k3sbthbz" ball-number="6" ball-type="k3sbthbz" href="javascript:void(0)" class="ball_number"><b>6</b></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</script>
<script type="text/html" id="k3slhtx_wf">
	<!--3连号同选-->
	<div id="k3slhtx" class="ball_section section_cqssc">
		<p class="remark" style="color:#999">
			对所有3个相连的号码（123、234、345、456）进行投注，任意号码开出，即为中奖。奖金<var class="tpl">{$peilv.k3slhtx}</var>倍
		</p>
		<div class="li_ball">
			<div class="ui-row-flex">
				<div class="ui-col ui-col-4 line-box">
					<ul class="ball_list_ul">
						<li style="width:100%" class="ball_item"><a ball-type="k3slhtx" playid="k3slhtx" ball-number="三连号通选" class="ball_number" href="javascript:void(0)"><b >三连号通选</b></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</script>
<script type="text/html" id="k3ethfx_wf">
	<!--2同号复选-->
	<div id="k3ethfx" class="ball_section section_cqssc">
		<p class="remark" style="color:#999">
			从11～66中任选1个或多个号码，选号与奖号（包含11～66，不限顺序）相同，即为中奖。奖金<var class="tpl">{$peilv.k3ethfx}</var>倍
		</p>
		<div class="li_ball">
			<div class="ui-row-flex">
				<div class="ui-col ui-col-4 line-box">
					<ul class="ball_list_ul">
						<li style="width:33.3%" class=" ball_item"><a ball-number="11" playid="k3ethfx" ball-type="k3ethfx" href="javascript:void(0)" class="ball_number"><b>11</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a ball-number="22" playid="k3ethfx" ball-type="k3ethfx" href="javascript:void(0)" class="ball_number"><b>22</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a ball-number="33" playid="k3ethfx" ball-type="k3ethfx" href="javascript:void(0)" class="ball_number"><b>33</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a ball-number="44" playid="k3ethfx" ball-type="k3ethfx" href="javascript:void(0)" class="ball_number"><b>44</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a ball-number="55" playid="k3ethfx" ball-type="k3ethfx" href="javascript:void(0)" class="ball_number"><b>55</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a ball-number="66" playid="k3ethfx" ball-type="k3ethfx" href="javascript:void(0)" class="ball_number"><b>66</b></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</script>
<script type="text/html" id="k3ethdx_wf">
	<!--2同号单选-->

	<div id="k3ethdx" class="ball_section section_cqssc">
		<p class="remark" style="color:#999">
			选择1对相同号码和1个不同号码投注，选号与奖号相同，即为中奖，奖金<var class="tpl">{$peilv.k3ethdx}</var>倍
		</p>
		<div class="gn_main_list">
			<ul class="ball_list_ul">
				<li style="width:100%;margin:8px 5px" class="li_ball curr">
					<ul style="width:100%;margin:auto" class="ball_list_ul ball_cont" id="ball_list_ul0">
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="11" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn"><b>11</b></a></li>
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="22" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn"><b>22</b></a></li>
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="33" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn"><b>33</b></a></li>
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="44" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn"><b>44</b></a></li>
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="55" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn"><b>55</b></a></li>
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="66" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn"><b>66</b></a></li>
					</ul>
				</li>
				<li style="width:100%;margin:8px 5px" class="li_ball curr">
					<ul style="width:100%;margin:auto" class="ball_list_ul ball_cont" id="ball_list_ul1">
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="1" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn1"><b>1</b></a></li>
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="2" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn1"><b>2</b></a></li>
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="3" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn1"><b>3</b></a></li>
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="4" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn1"><b>4</b></a></li>
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="5" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn1"><b>5</b></a></li>
						<li style="width:16.6%;padding:5px 5px;" class="ball_item"><a ball-number="6" ball-type="k3ethdx" playid="k3ethdx" href="javascript:void(0)" class="ball_number ethdx_btn1"><b>6</b></a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
</script>
<script type="text/html" id="k3ebthbz_wf">
	<!--2不同号-->
	<div id="k3ebthbz" class="ball_section section_cqssc">
		<p class="remark" style="color:#999">
			从1～6中任选2个或多个号码，所选号码与开奖号码任意2个号码相同，即为中奖。奖金<var class="tpl">{$peilv.k3ebthbz}</var>倍
		</p>
		<div class="li_ball">
			<div class="ui-row-flex">
				<div class="ui-col ui-col-4 line-box gn_main_list">
					<ul class="ball_list_ul">
						<li style="width:33.3%" class=" ball_item"><a ball-number="1" ball-type="k3ebthbz" playid="k3ebthbz" href="javascript:void(0)" class="ball_number"><b>1</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a ball-number="2" ball-type="k3ebthbz" playid="k3ebthbz" href="javascript:void(0)" class="ball_number"><b>2</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a ball-number="3" ball-type="k3ebthbz" playid="k3ebthbz" href="javascript:void(0)" class="ball_number"><b>3</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a ball-number="4" ball-type="k3ebthbz" playid="k3ebthbz" href="javascript:void(0)" class="ball_number"><b>4</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a ball-number="5" ball-type="k3ebthbz" playid="k3ebthbz" href="javascript:void(0)" class="ball_number"><b>5</b></a></li>
						<li style="width:33.3%" class=" ball_item"><a ball-number="6" ball-type="k3ebthbz" playid="k3ebthbz" href="javascript:void(0)" class="ball_number"><b>6</b></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</script>
