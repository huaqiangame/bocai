<include file="Public/header" />
<link rel="stylesheet" href="__CSS__/activity.css">

</head>
<body class="bg_fff">
	<header data-am-widget="header"class="am-header am-header-default header nav_bg am-header-fixed">
		<div class="am-header-left am-header-nav">
			<a href="javascript:history.back(-1);" class="">
				<i class="iconfont icon-arrow-left"></i>
			</a>
      	</div>

		<h1 class="am-header-title activity_h1">
			晋级奖励
		</h1>
	</header>
	<div class="promotion_main">
	<h2 class="promotion_h2">
				活动说明
			</h2>
	<p style="">为回馈广大新老会员，福利彩每月定期派送彩金。详情如下:</p><p style=""><br></p><ol style="width:744.797px;"><li><p>&nbsp;VIP4每月五号.赠送18元彩金；</p></li><li><p>&nbsp;VIP5每月五号赠送18元彩金；十五号赠送18元彩金；</p></li><li><p>&nbsp;VIP6每月五号赠送38元彩金；十五号赠送38元彩金；</p></li><li><p>&nbsp;VIP7每月五号赠送88元彩金 &nbsp;；十五号赠送88元彩金 ；</p></li><li><p>&nbsp;VIP8每月五号赠送168元彩金；十五号赠送168元彩金；</p></li><li><p>&nbsp;VIP9每月五号赠送888元彩金；十五号赠送888元彩金；<br></p></li></ol><p style="">&nbsp;</p><p style=""><br></p><table><tbody><tr><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 192, 0);">&nbsp; &nbsp;会员等级</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; 日期</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; 派送金额</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;日期</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp;派送金额</span></td></tr><tr><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 192, 0);">&nbsp; &nbsp; &nbsp;VIP4&nbsp;</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;5</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp; 18</span></td><td width="128" valign="top" style="word-break:break-all;"><br></td><td width="128" valign="top"><br></td></tr><tr><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 192, 0);">&nbsp; &nbsp; &nbsp;VIP5</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;5</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp; 18</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; 15</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;18</span></td></tr><tr><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 192, 0);">&nbsp; &nbsp; &nbsp;VIP6</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;5</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp; 38</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; 15</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;38</span></td></tr><tr><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 192, 0);">&nbsp; &nbsp; &nbsp;VIP7</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;5</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp; 88</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; 15</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;88</span></td></tr><tr><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 192, 0);">&nbsp; &nbsp; &nbsp;VIP8</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;5</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp;168</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; 15</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp; 168</span></td></tr><tr><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 192, 0);">&nbsp; &nbsp; &nbsp;VIP9</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp;5</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp;888</span></td><td width="128" valign="top" style="word-break:break-all;">&nbsp; &nbsp; &nbsp; &nbsp; 15</td><td width="128" valign="top" style="word-break:break-all;"><span style="color:rgb(255, 0, 0);">&nbsp; &nbsp; &nbsp; &nbsp; 888</span></td></tr></tbody></table><p style=""><br></p><p style=""><br></p><p style=""><span style="color:rgb(0, 176, 240);">VIP等级累计时间为赠送彩金的前一天，也就是每月的4号、14号24点前截止。</span></p><p style=""><span style="color:rgb(255, 0, 0);">&nbsp;24：00 前如有，没自动到账的明天可以联系在线客服！</span></p><p style=""><span style="color:rgb(255, 0, 0);"></span><br></p><p style=""><br></p><p style=""><br></p><p style=""><br></p><p style=""><br></p><p><br></p>
	</div>

	<include file="Public/footer" />
	<script type="text/javascript">
		function jiangli(){
			$.post("{:U('Activity/jinji')}",'', function(json){
				if(json.status==1){
					alert(json.info);
					window.location.reload();
				}else{
					alert(json.info);
				}
			},'json');
			return false;
		}
	</script>
</body>
</html>